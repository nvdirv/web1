from django.views.generic import ListView
from .models import Post


class ListView (ListView):
	model = Post
	template_name = 'home.html'

def blog_list (request):
	//
    return render (request, 'Blog1/base.html', {"blogs": blogs, "active_menu": "blog"})

def blog_add (request):
    if (request.method == 'POST'):
        name = request.POST['name']
        blog.save()
        return redirect('/Blog1')
    else:
        return render(request, "Blog1/blog_add.html", {"active_menu": "blog"})

def blog_delete (request, blog_id):
    blog = Blog1.objects.get (pk=blog_id)
    blog.delete()
    return redirect('/blogs')


ef blog_list(request):
    blogs = Blog.objects.all()#order_by('-published_date')
    return render(request, 'blog_list.html', {'blogs': blogs})


def blog_edit(request, blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    if request.method == "POST":
        form = BlogForm(request.POST, instance=blog)
        if form.is_valid():
            blog = form.save(commit=False)
            blog.save()
            return redirect('blog_list')
    else:
        form = BlogForm(instance=blog)
    return render(request, 'blog_edit.html', {'form': form, "type": 1})


def blog_new(request):
    if request.method == "POST":
        form = BlogForm(request.POST)
        if form.is_valid():
            blog = form.save(commit=False)
            blog.save()
            return redirect('blog_list')
    else:
        form = BlogForm()
    return render(request, 'blog_edit.html', {'form': form, "type": 1})
	

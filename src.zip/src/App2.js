import React from 'React';

class App2 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isClicked: false,
    };
  }

  handleButtonClicked = () => {
    if(!this.state.isCLicked) {
      this.setState({isClicked: true});
    } else {
      this.setState({isClicked: false});
    }
    
  }
};

render() {
    return(
      <div className="App2">
          <div className="App2">
            <Router>
            <p> 
              <button className="button1"onClick={(e) => this.handleButtonClicked(this.props.isClicked)}>Home</button>
            </p>
            <p> 
              <button className="button2"onClick={(e) => this.handleButtonClicked(this.props.isClicked)}>Index</button>
            </p>
            <p> 
              <button className="button3"onClick={(e) => this.handleButtonClicked(this.props.isClicked)}>Contact</button>
            </p>

          </div>
          </div>
    );
  }

 export default App2;


import React, {Component}from 'react';
import logo from './logo.svg';
import './App.css';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';

class App extends Component{
  constructor(props) {
    super(props);
    this.handleButtonClicked = this.handleButtonClicked(bind).this;

    this.state = {
      buttons: [{id:0, name:"Home"},
                {id:1, name:"Index"},
                {id:2, name:"Contact"} ]
    }
  }

  handleButtonClicked = () => {
    if(!this.state.isCLicked) {
      this.setState({isClicked: true});
    } else {
      this.setState({isClicked: false});
    }
    
  }



  render() {
    let buttons = this.state.buttons.map((isClicked) => {
      return <buttons name={buttons.name}  id={buttons.id} handleButtonClicked={this.handleButtonClicked}/>
       })
    return (
      <div className="App">
          <div className="App">
            <Router>
            <p> 
              <button className="button1"onClick={(e) => this.handleButtonClicked(this.props.isClicked)}></button>
            </p>
            <p> 
              <button className="button2"onClick={(e) => this.handleButtonClicked(this.props.isClicked)}></button>
            </p>
            <p> 
              <button className="button3"onClick={(e) => this.handleButtonClicked(this.props.isClicked)}></button>
            </p>
            </Router>
          </div>
          </div>
    );
  }
}

export default App;
